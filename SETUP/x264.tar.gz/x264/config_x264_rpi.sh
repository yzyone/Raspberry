#!/bin/sh
./configure --disable-shared --enable-static --enable-strip --disable-cli
